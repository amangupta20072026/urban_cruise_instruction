/**
 * ------------------------------------------------------------------
 * Toast store — unit tests
 * ------------------------------------------------------------------
 * Covers the security-critical properties of the store — the ones
 * that make it "production-grade":
 *
 *   - INSERTS append and emit exactly once.
 *   - DEDUP within window resets the existing timer, does not add.
 *   - OVERFLOW drops the OLDEST and never breaks MAX_VISIBLE.
 *   - REPLACE by id patches in place, clears the old timer, and
 *     schedules a new one.
 *   - DISMISS is idempotent and clears timers.
 *   - `dismissAll` cancels every timer and empties the array.
 *   - `loading` variant does NOT schedule an auto-dismiss.
 *   - Duration 0 falls back to the variant default.
 *   - Duration Infinity pins.
 *
 * Timers are driven by jest's fake-timer API. React is not mounted.
 * ------------------------------------------------------------------
 */

import {
  _resetForTests,
  dismiss,
  dismissAll,
  getSnapshot,
  show,
  subscribe,
} from '../store';

/* ================================================================
 * Test harness
 * ================================================================ */

beforeEach(() => {
  jest.useFakeTimers();
  _resetForTests();
});

afterEach(() => {
  jest.useRealTimers();
});

describe('show()', () => {
  it('appends a new toast and emits exactly once', () => {
    const listener = jest.fn();
    const unsub = subscribe(listener);

    const id = show('info', 'Hello');

    expect(getSnapshot()).toHaveLength(1);
    expect(getSnapshot()[0]).toMatchObject({ id, kind: 'info', title: 'Hello' });
    expect(listener).toHaveBeenCalledTimes(1);
    unsub();
  });

  it('produces a NEW snapshot reference on every mutation', () => {
    const before = getSnapshot();
    show('info', 'A');
    const after = getSnapshot();
    expect(after).not.toBe(before);
  });

  it('returns a stable id for the same call site', () => {
    const id1 = show('info', 'One');
    const id2 = show('info', 'Two');
    expect(id1).not.toBe(id2);
  });
});

describe('dedup', () => {
  it('resets the timer for a duplicate within the window instead of adding', () => {
    // Error variant default duration is 5000 ms.
    const id1 = show('error', 'Same message');
    expect(getSnapshot()).toHaveLength(1);

    // Advance INSIDE the dedup window (1500 ms). Any duplicate
    // arriving here must hit the same id and reset the timer.
    jest.advanceTimersByTime(1000);
    const id2 = show('error', 'Same message');

    expect(id2).toBe(id1);
    expect(getSnapshot()).toHaveLength(1);

    // Original 5s would have fired at t=5000ms. After the reset at
    // t=1000ms, the new timer fires at t=6000ms.
    jest.advanceTimersByTime(4000); // now t=5000, past original
    expect(getSnapshot()).toHaveLength(1);

    jest.advanceTimersByTime(1500); // now t=6500, past reset
    expect(getSnapshot()).toHaveLength(0);
  });

  it('does NOT dedup once the window has elapsed', () => {
    const id1 = show('info', 'Ping');
    jest.advanceTimersByTime(1600); // past 1500 ms window
    const id2 = show('info', 'Ping');
    expect(id2).not.toBe(id1);
    // First one auto-dismissed after 3s from t=0, so at t=3000.
    // At t=1600 it's still visible. Expect 2 items.
    expect(getSnapshot()).toHaveLength(2);
  });

  it('does NOT dedup across different kinds', () => {
    show('error', 'msg');
    show('info', 'msg');
    expect(getSnapshot()).toHaveLength(2);
  });

  it('does NOT dedup across different descriptions', () => {
    show('info', 'title', { description: 'A' });
    show('info', 'title', { description: 'B' });
    expect(getSnapshot()).toHaveLength(2);
  });
});

describe('overflow (MAX_VISIBLE = 3)', () => {
  it('drops the OLDEST when a fourth item arrives', () => {
    const id1 = show('info', '1');
    const id2 = show('info', '2');
    const id3 = show('info', '3');
    const id4 = show('info', '4');

    const items = getSnapshot();
    expect(items.map(i => i.id)).toEqual([id2, id3, id4]);
    // First id evicted
    expect(items.find(i => i.id === id1)).toBeUndefined();
  });

  it('cancels the timer of the evicted toast', () => {
    // Fill the buffer with error toasts (5s each)
    show('error', '1');
    show('error', '2');
    show('error', '3');
    show('error', '4'); // '1' evicted, its timer should be dead

    // Advance past what would have been '1' original expiry;
    // nothing should try to dismiss a nonexistent id.
    jest.advanceTimersByTime(6000);
    // '1' through '3' all had their 5s timers fire — only whatever
    // was added last within the window remains, if not yet expired.
    expect(getSnapshot()).toHaveLength(0);
  });
});

describe('replace-in-place', () => {
  it('swaps kind/title/description at the same index and same id', () => {
    const id = show('loading', 'Uploading…');
    expect(getSnapshot()[0]).toMatchObject({ kind: 'loading', title: 'Uploading…' });

    show('success', 'Uploaded', { id });

    const items = getSnapshot();
    expect(items).toHaveLength(1);
    expect(items[0]).toMatchObject({ id, kind: 'success', title: 'Uploaded' });
  });

  it('clears the old timer and schedules the new one', () => {
    const id = show('error', 'Err', { duration: 10_000 });
    show('success', 'OK', { id }); // success default is 3s

    jest.advanceTimersByTime(2999);
    expect(getSnapshot()).toHaveLength(1);

    jest.advanceTimersByTime(2);
    expect(getSnapshot()).toHaveLength(0);
  });

  it('inserts if the explicit id does not already exist', () => {
    const id = show('info', 'Hi', { id: 'custom-id' });
    expect(id).toBe('custom-id');
    expect(getSnapshot()[0]!.id).toBe('custom-id');
  });
});

describe('duration handling', () => {
  it('loading is pinned (no auto-dismiss)', () => {
    show('loading', 'Waiting…');
    jest.advanceTimersByTime(60_000);
    expect(getSnapshot()).toHaveLength(1);
  });

  it('duration: 0 falls back to variant default', () => {
    show('success', 'Yay', { duration: 0 });
    jest.advanceTimersByTime(2999);
    expect(getSnapshot()).toHaveLength(1);
    jest.advanceTimersByTime(2);
    expect(getSnapshot()).toHaveLength(0);
  });

  it('duration: Infinity pins', () => {
    show('info', 'Sticky', { duration: Infinity });
    jest.advanceTimersByTime(60_000);
    expect(getSnapshot()).toHaveLength(1);
  });

  it('negative / NaN duration falls back to default', () => {
    show('info', 'x', { duration: -100 });
    show('info', 'y', { duration: Number.NaN });
    jest.advanceTimersByTime(2999);
    expect(getSnapshot()).toHaveLength(2);
    jest.advanceTimersByTime(2);
    expect(getSnapshot()).toHaveLength(0);
  });
});

describe('dismiss()', () => {
  it('removes the toast and emits', () => {
    const listener = jest.fn();
    const unsub = subscribe(listener);

    const id = show('info', 'A');
    listener.mockClear();
    dismiss(id);

    expect(getSnapshot()).toHaveLength(0);
    expect(listener).toHaveBeenCalledTimes(1);
    unsub();
  });

  it('is a no-op for an unknown id and does not emit', () => {
    const listener = jest.fn();
    const unsub = subscribe(listener);

    dismiss('nonsense');

    expect(listener).not.toHaveBeenCalled();
    unsub();
  });

  it('cancels the timer so a late tick does not double-fire', () => {
    const id = show('info', 'A'); // 3s default
    jest.advanceTimersByTime(1000);
    dismiss(id);
    jest.advanceTimersByTime(5000); // well past original expiry
    // No throw, no ghost emission.
    expect(getSnapshot()).toHaveLength(0);
  });
});

describe('dismissAll()', () => {
  it('empties the array and cancels every timer', () => {
    show('info', '1');
    show('error', '2');
    show('warning', '3');
    dismissAll();

    expect(getSnapshot()).toHaveLength(0);

    // Advance well past every default duration — nothing should
    // try to mutate state and re-emit.
    const listener = jest.fn();
    const unsub = subscribe(listener);
    jest.advanceTimersByTime(60_000);
    expect(listener).not.toHaveBeenCalled();
    unsub();
  });

  it('is a no-op when nothing is queued', () => {
    const listener = jest.fn();
    const unsub = subscribe(listener);
    dismissAll();
    expect(listener).not.toHaveBeenCalled();
    unsub();
  });
});

describe('subscriber isolation', () => {
  it('a throwing subscriber does not prevent siblings from receiving', () => {
    const good = jest.fn();
    const bad = jest.fn(() => {
      throw new Error('boom');
    });

    const u1 = subscribe(bad);
    const u2 = subscribe(good);

    show('info', 'X');

    expect(bad).toHaveBeenCalledTimes(1);
    expect(good).toHaveBeenCalledTimes(1);

    u1();
    u2();
  });
});
