# Centralized Toast — bundle

## Contents

- `toast/` — the new module. Drop into `src/services/toast/`.
  - `types.ts`
  - `variantConstants.ts`
  - `variantStyles.ts`
  - `store.ts`
  - `api.ts`
  - `ToastItemView.tsx`
  - `ToastHost.tsx`
  - `index.ts`
  - `__tests__/store.test.ts`

- `modified/` — files that already exist in your repo and were edited.
  Overwrite the corresponding paths.
  - `App.tsx`                → repo root `App.tsx`
  - `drain.ts`               → `src/services/deeplinks/drain.ts`

## Verify

  npx tsc --noEmit
  npx jest src/services/toast/__tests__/store.test.ts

## Use

  import { toast } from '@services/toast';
  toast.success('Booking confirmed');
